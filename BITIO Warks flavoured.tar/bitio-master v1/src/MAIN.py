import mc_microbit as m
m.build()


while True:
    m.microbit.display.scroll("#T4GEduBlocks")
