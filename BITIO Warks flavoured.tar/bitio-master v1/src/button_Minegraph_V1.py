"""
Written by @ncscomputing on top of the bitio produced by David Whale 
"""
import serial
from mcpi.minecraft import Minecraft
from time import sleep
from mcpi import block as block
import random


mc = Minecraft.create()

BlockIdList = [1,2,3,4,5,6,7,8,9,20,26,89]
# button.py - demonstrates using a button

import time
import microbit

###
from sense_emu import SenseHat
import mcpi.minecraft as minecraft
import mcpi.block as block
import time
import random


"""
NCS team Pixel Astro Pi competition entry

We have created a bar graph in minecraft and store the values for temp and
humidity in two seperate lists.


Team members are:
Archie
Tom
Adrian
"""

sense = SenseHat()

mc = minecraft.Minecraft.create()
orx,ory,orz = mc.player.getPos()

mc.postToChat("Start Graph")

TempBlock = 35,14

HumidityBlock = 35,3
Temperature_List = []#stores temp data
Humidity_List = []#stores humidity data

DataStreamCount= 0

def BuildDataBlockTemp(ImportedBlock):# take data for temp
    temp = int(sense.temp)
    Temperature_List.append(temp)
    orx,ory,orz = mc.player.getPos()

    for i in range (0,temp):
        x,y,z = mc.player.getPos()
        mc.setBlock(x+30,i,z,ImportedBlock)
    mc.player.setPos(orx,ory,orz+1)
    msg = "Temp = {0}".format(temp)
    #sense.show_message(msg, scroll_speed=0.10 )
    print(msg)
    time.sleep(1)
def BuildDataBlockHumidity(ImportedBlock):# take data for humidity
    humidity = int(sense.humidity)
    Humidity_List.append(humidity)
    orx,ory,orz = mc.player.getPos()
    for i in range (0,humidity):
        x,y,z = mc.player.getPos()
        mc.setBlock(x+30,i,z,ImportedBlock)
    mc.player.setPos(orx,ory,orz+1)
    msg = "Humidity currently is: ",humidity
    print(msg)
    msg = "humidity = {0}".format(humidity)
 
    time.sleep(4)


print("micro:bit connected - press button A to test")

while True:
    time.sleep(0.25)
    if microbit.button_a.was_pressed():
        print("Button A pressed")
        pos = mc.player.getPos()
        #BlockID = random.choice(BlockIdList)
        msg = "Building Graph...."
        mc.postToChat(msg)
        microbit.display.show(msg)
        time.sleep(0.5)
        BuildDataBlockTemp(TempBlock) # 46
        BuildDataBlockHumidity(HumidityBlock)
    if microbit.button_b.was_pressed():
        mc.postToChat("Graph ended")
        time.sleep(1)
        break
        

    

###
