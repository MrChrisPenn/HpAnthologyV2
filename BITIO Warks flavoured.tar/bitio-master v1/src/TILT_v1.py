import mcpi.minecraft as minecraft
import microbit
import time

import serial
from starwarscraft import XWingFighter
from bomb import Bomb
#from mcpi.minecraft import Minecraft
from time import sleep

mc = minecraft.Minecraft.create()

##
try:
    playerPos = mc.player.getTilePos()
    craftPos = playerPos.clone()
    craftPos.y += 10
    craftPos.z += 20
    craft = XWingFighter(craftPos)
    #bomb = Bomb()
    
    while True:
        x = microbit.accelerometer.get_x()
        y = microbit.accelerometer.get_y()
        z = microbit.accelerometer.get_z()
        if a:
            if craft.flying:
                craft.stop()
            else:
                craft.fly(0.15)
        if b:
            bpos = craft.craftShape.position
            bpos.y - 2
            bomb.drop(bpos.x, bpos.y, bpos.z, 0.1)
        if x > 750:
            craft.turn(10)
        if x > 500:
            craft.turn(5)
        if x < -750:
            craft.turn(-10)
        if x < -500:
            craft.turn(-5)
        if x > -500 and x < 500:
            craft.turn(0)
    
finally:
    sleep(1)
    craft.clear()
    s.close()
##

