import mc_microbit as m
import time

m.build()


while True:

    theTime = time.ctime()
    print theTime[11]
    m.microbit.display.show_char(theTime[11])
    time.sleep(2)

    print theTime[12]
    m.microbit.display.show_char(theTime[12])
    time.sleep(2)
    print theTime[14]
    m.microbit.display.show_char(theTime[14])
    time.sleep(2)
    print theTime[15]
    m.microbit.display.show_char(theTime[15])
    time.sleep(2)
