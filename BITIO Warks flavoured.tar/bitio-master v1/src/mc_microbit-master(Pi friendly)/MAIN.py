import mc_microbit as m
m.build()


def main():
    while True:
        m.microbit.display.scroll("#T4GEduBlocks")
