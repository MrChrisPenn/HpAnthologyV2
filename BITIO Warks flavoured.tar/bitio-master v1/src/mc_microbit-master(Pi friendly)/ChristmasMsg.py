import mc_microbit as m
import time

m.build()


while True:

    m.microbit.display.scroll("Happy Chrimbo")
    time.sleep(2)
