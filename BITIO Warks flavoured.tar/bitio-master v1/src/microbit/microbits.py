# microbits.py - provide non auto connect to 1 or more microbits

print("microbits imported")

#TODO: The idea of this is to have a microbit factory, that won't auto connect
#to a single microbit, and will allow multiple to be discovered and used.
