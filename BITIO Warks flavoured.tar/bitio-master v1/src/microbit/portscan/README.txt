PORTSCAN - a package that scans serial ports.
